import React from "react";
import { useNavigate } from "react-router-dom";

const Upload = () => {
  const navigate = useNavigate();

  const handleUpload = () => {
    // Handle image upload logic
    navigate("/loading");
  };

  return (
    <div>
      <h2>Upload from Gallery</h2>
      <input type="file" accept="image/*" />
      <button onClick={handleUpload}>Upload</button>
    </div>
  );
};

export default Upload;
