import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Home from "./Home";
import Login from "./Login";
import Register from "./Register";
import Detection from "./Detection";
import Upload from "./Upload";
import Loading from "./Loading";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="./Home" element={<Home />} />
        <Route path="./login" element={<Login />} />
        <Route path="./register" element={<Register />} />
        <Route path="./detection" element={<Detection />} />
        <Route path="./upload" element={<Upload />} />
        <Route path="./loading" element={<Loading />} />
      </Routes>
    </Router>
  );
}

export default App;
