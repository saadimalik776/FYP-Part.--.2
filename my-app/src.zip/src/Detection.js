import React from "react";
import { useNavigate } from "react-router-dom";

const Detection = () => {
  const navigate = useNavigate();

  return (
    <div>
      <h2>Detection</h2>
      <button onClick={() => navigate("/upload")}>Detect</button>
    </div>
  );
};

export default Detection;
